#include "data_global.h"

void * pthread_refresh(void * arg)
{
	printf("%s\n",__FUNCTION__);
}

