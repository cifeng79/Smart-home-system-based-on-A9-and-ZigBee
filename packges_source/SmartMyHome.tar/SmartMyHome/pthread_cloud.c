#include "data_global.h"


void * pthread_cloud(void *arg)
{
	printf("-------------%s-------------\n",__FUNCTION__);
	return 0;
}

