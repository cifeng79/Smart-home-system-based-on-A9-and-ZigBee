#include "data_global.h"


void * pthread_sqlite(void * arg)
{
	printf("--------%s-------------\n",__FUNCTION__);
}





