#include "data_global.h"

void *pthread_fan(void *arg)
{
	printf("----------%s-------\n",__FUNCTION__);
}
