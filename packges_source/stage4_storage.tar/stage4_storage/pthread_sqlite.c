
#include "data_global.h"

//:���ݿ��߳�.
void *pthread_sqlite(void *arg)
{

	printf("pthread_sqlite\n");
}




