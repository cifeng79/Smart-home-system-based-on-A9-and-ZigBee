

#include "data_global.h"


void *pthread_buzzer(void *arg)
{
	printf("pthread_buzzer\n");

}



