#include "data_global.h"

void *pthread_sms(void *arg)
{

	printf("pthread_sms\n");
}



